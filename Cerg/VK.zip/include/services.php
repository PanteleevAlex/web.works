﻿<!DOCTYPE html>
<html>
<meta charset='utf-8'>

<link href="style.css" rel="stylesheet" type"text/css">
<link href="../css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="../css/fonts.css" rel="stylesheet" type="text/css">
<link href="../css/main.css" rel="stylesheet" type="text/css">
<link href="../css/lightbox.css" rel="stylesheet" type="text/css">
<script src="../js/lightbox-plus-jquery.min.js"></script>
<script src="../js/jquery-2.1.4.min.js"></script>
<script src="../js/cycle.js"></script>
<script src="../js/main.js"></script>


	<title>Услуги</title>

<div class='site'>
	<div class='div_li'>

	   <div class=call>
		    Звоните: +7(812)318-70-15 
		   <br>
		   по буднями с 9:00 до 18:00 
	   </div> <!--end coll-->
	<ul class='ul_list'>
		<a href='../index.php'<li>Главная</li>
		<a href='services.php'><li>Услуги</li></a>
		<li class='li_logo'><img src='../img/logo.png' alt='Логотип'></li>
		<a href='portfolio.php'><li>Портфолио</li></a>
		<a href='responses.php'><li>Отзывы</li></a>
		<a href='contact.php'><li>Контакты</li></a>
		</ul>
	</div> <!--end div_li-->
		<div class=div_img></div>
<div class=div_p>
<p> С footer у меня с самого начала изучения html, css не заладилось. 
И с этим тоже долго возился. Столько способов перепробовал, пока добился того что есть и уже боялся хоть что-то там изменить, что бы не испортить все и не восстанавливать заново.
А с иконкой email вообще ни чего не мог сделать!!!</p>
</div> <!--end div_p-->


<div class='footer'>
   <table class='footer_table'>
   <tr>

		<th class='td_home'><img src='../img/home.png' alt='Изображение' title='home' class='home_img'>
		<p>СПб.ул. Учительская,д 18.к.3.пом2Н,лит.А</p></th> <!--end td_home-->

		<th class='td_phone'><img src='../img/phone.png' alt='Изображение' title='phone' class='phone_span'>
		<p>+7(812)318-70-15</p></th><!-- end td_phone-->

		<th class='td_envelope'> <p class='fa fa-envelope-o'></p><br>
		<span class='spd@'>sdp-spd@mail.ru</span> </th><!--end td_envelope-->
   </tr>
		<table>
		   <tr>
			<th class='td_OOO'><p class='p_OOO'>© 2014 OOO "СтройДизайт Проект". Дизайтна сайта: tipovaya</p></th>
		   </tr>
		</table>
</table>
</div> <!--footer-->

	<div class='clearfix'></div>
	
<script src='../js/lightbox-plus-jquery.min.js'></script>
</div><!--end site-->
</html>

