﻿<!DOCTYPE html>
<html>
<meta charset='utf-8'>

<link href="style.css" rel="stylesheet" type"text/css">
<link href="../css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="../css/fonts.css" rel="stylesheet" type="text/css">
<link href="../css/main.css" rel="stylesheet" type="text/css">
<link href="../css/lightbox.css" rel="stylesheet" type="text/css">
<script src="../js/lightbox-plus-jquery.min.js"></script>
<script src="../js/jquery-2.1.4.min.js"></script>
<script src="../js/cycle.js"></script>
<script src="../js/main.js"></script>


	<title>Портфолио</title>

<div class='site'>
	<div class='div_li'>

	   <div class=call>
		    Звоните: +7(812)318-70-15 
		   <br>
		   по буднями с 9:00 до 18:00 
	   </div> <!--end coll-->
	<ul class='ul_list'>
		<a href='../index.php'<li>Главная</li>
		<a href='include/services.php'><li>Услуги</li></a>
		<li class='li_logo'><img src='../img/logo.png' alt='Логотип'></li>
		<a href='include/responses.php'><li>Отзывы</li></a>
		<a href='include/contact.php'><li>Контакты</li></a>
		</ul>
	</div> <!--end div_li-->
		<div class=div_img></div>
<div class=div_p>
<p> </p>
</div> <!--end div_p-->


	<div class='div_vk'>
		<a href="../img/mountains.jpg" data-lightbox="image" data-title="Горы">
		<img src="../img/smail/mountains.jpg" class="mountains">
		</a>


		<a href="../img/China.jpg" data-lightbox="image" data-title="Китай">
		<img src="../img/smail/China.jpg" class="China">
		</a>


		<a href="../img/decline.jpg" data-lightbox="image" data-title="Закат">
		<img src="../img/smail/decline.jpg" class="decline">
		</a>

		<a href="../img/house_island.jpg" data-lightbox="image" data-title="Дом на острове...'Чтоб я так жил (отдыхал:-)!!!'">
		<img src="../img/smail/house_island.jpg" class="island">
		</a>
	</div><!--end div_vk-->

<p class='img_p'>На <b>JavaScript</b> я и строчки не могу написать.<br> С трудом найти что-то, поменять, это максимум.

<div class=div_p_II>
<p class='b'><b></b><br></p>
</div> <!--end div_p_II-->

<div class='footer'>
   <table class='footer_table'>
   <tr>

		<th class='td_home'><img src='../img/home.png' alt='Изображение' title='home' class='home_img'>
		<p>СПб.ул. Учительская,д 18.к.3.пом2Н,лит.А</p></th> <!--end td_home-->

		<th class='td_phone'><img src='../img/phone.png' alt='Изображение' title='phone' class='phone_span'>
		<p>+7(812)318-70-15</p></th><!-- end td_phone-->

		<th class='td_envelope'> <p class='fa fa-envelope-o'></p><br>
		<span class='spd@'>sdp-spd@mail.ru</span> </th><!--end td_envelope-->
   </tr>
		<table>
		   <tr>
			<th class='td_OOO'><p class='p_OOO'>© 2014 OOO "СтройДизайт Проект". Дизайтна сайта: tipovaya</p></th>
		   </tr>
		</table>
</table>
</div> <!--footer-->

	<div class='clearfix'></div>
	
<script src='../js/lightbox-plus-jquery.min.js'></script>
</div><!--end site-->
</html>

