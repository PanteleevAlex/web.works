﻿<!DOCTYPE html>
<html>
<meta charset='utf-8'>

<link href="style.css" rel="stylesheet" type"text/css">
<link href='http://fonts.googleapis.com/css?family=Roboto&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Ubuntu&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
<link href="../css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="../css/fonts.css" rel="stylesheet" type="text/css">
<link href="../css/main.css" rel="stylesheet" type="text/css">
<link href="../css/lightbox.css" rel="stylesheet" type="text/css">
<script src="../js/lightbox-plus-jquery.min.js"></script>
<script src="../js/jquery-2.1.4.min.js"></script>
<script src="../js/cycle.js"></script>
<script src="../js/main.js"></script>


	<title>Контакты</title>

<div class='site'>
	<div class='div_li'>

	   <div class=call>
		    Звоните: +7(812)318-70-15 
		   <br>
		   по буднями с 9:00 до 18:00 
	   </div> <!--end coll-->
	<ul class='ul_list'>
		<a href='../index.php'<li>Главная</li>
		<a href='services.php'><li>Услуги</li></a>
		<li class='li_logo'><img src='../img/logo.png' alt='Логотип'></li>
		<a href='portfolio.php'><li>Портфолио</li></a>
		<a href='responses.php'><li>Отзывы</li></a>
		<a href='contact.php'><li>Контакты</li></a>
		</ul>
	</div> <!--end div_li-->
		<div class=div_img></div>

<p class='contact_p'>Блок с отправкой сообщений хотел опустить почти к самому футеру, но он сдвинулся вниз до определённого предела и как упёрся в невидимую преграду.</p>

	<div class='contact'>
		<form method='post' action='index.php'>
			<textarea placeholder='You Mame'></textarea>
<br><br>
			<textarea placeholder='You E-Mail Address'></textarea>
<br><br>
						<input type='submit' value='Oтправить'>
					   <p class='p-massege'>
	    		<textarea placeholder='You Massege'></textarea>
<br><br>
					   </p>
						<input type='submit' value='Oтправить'>
		</form>
	</div> <!--end contact-->


<div class='footer'>
   <table class='footer_table'>
   <tr>

		<th class='td_home'><img src='../img/home.png' alt='Изображение' title='home' class='home_img'>
		<p>СПб.ул. Учительская,д 18.к.3.пом2Н,лит.А</p></th> <!--end td_home-->

		<th class='td_phone'><img src='../img/phone.png' alt='Изображение' title='phone' class='phone_span'>
		<p>+7(812)318-70-15</p></th><!-- end td_phone-->

		<th class='td_envelope'> <p class='fa fa-envelope-o'></p><br>
		<span class='spd@'>sdp-spd@mail.ru</span> </th><!--end td_envelope-->
   </tr>
		<table>
		   <tr>
			<th class='td_OOO'><p class='p_OOO'>© 2014 OOO "СтройДизайт Проект". Дизайтна сайта: tipovaya</p></th>
		   </tr>
		</table>
</table>
</div> <!--footer-->

	<div class='clearfix'></div>
	
<script src='../js/lightbox-plus-jquery.min.js'></script>
</div><!--end site-->
</html>

